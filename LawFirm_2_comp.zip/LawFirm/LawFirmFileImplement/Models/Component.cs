﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LawFirmFileImplement.Models
{
    public class Component
    {
        public int Id { get; set; }
        public string ComponentName { get; set; }
    }
}